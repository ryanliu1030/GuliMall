create definer = `mysql.sys`@localhost view schema_index_statistics as
select `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`                      AS `table_schema`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`                        AS `table_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME`                         AS `index_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_FETCH`                        AS `rows_selected`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_FETCH`)  AS `select_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_INSERT`                       AS `rows_inserted`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_INSERT`) AS `insert_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_UPDATE`                       AS `rows_updated`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_UPDATE`) AS `update_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_DELETE`                       AS `rows_deleted`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_DELETE`) AS `delete_latency`
from `performance_schema`.`table_io_waits_summary_by_index_usage`
where (`performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` is not null)
order by `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_WAIT` desc;

